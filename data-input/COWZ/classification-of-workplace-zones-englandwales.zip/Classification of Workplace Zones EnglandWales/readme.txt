
2011 COWZ-EW Geodata Pack - England/Wales

+ Abstract:

The 2011 Classification Of Workplace Zones (2011 COWZ-EW) is a UK geodemographic classification produced as a collaboration between the Office for National Statistics and the University of Southampton. For further information regarding the 2011 COWZ-EW which may include newer additions to the shapefile and csv file please visit:

http://cowz.geodata.soton.ac.uk/

+ Contents:
	- Shapefiles
		- COWZ_EW_2011_BFC (.shp,.prj,.dbf,.shx): Shapefile
	- Tables
		- COWZ_EW_2011_Classification.csv - Workplace Zone / Small Area Supergroup,Group lookup
		- COWZ_EW_2011_Names_and_Colours.csv: Suggested colours for the classifications
	- metadata.xml: Meta Data
	- readme.txt: Information about the CDRC 2011 COWZ-EW Geodata

+ Attributes:
	- WZ11CD: Workplace Zone code (2011 Version)
	- LAD11CD: Local Authority code (2011 Version)
	- COWZEW_SGC: Supergroup code
	- COWZEW_SGN: Supergroup name
	- COWZEW_GC: Group code
	- COWZEW_GN: Group name
	
+ Copyright and citation:

Please cite with the following copyright and attribution statement:

2011 COWZ-EW Geodata Pack by the University of Southampton; Contains public sector information licensed under the Open Government Licence
v2.0. Contains National Statistics and Ordnance Survey data © Crown copyright and database right 2015.

+ Funding:

Funded by: ONS, Quality Improvement Fund (QIF).
